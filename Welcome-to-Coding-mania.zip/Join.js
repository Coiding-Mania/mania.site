function goToLink(link) {
    window.open(link, "_blank");
}